const images = [
  'https://yourdomain.com/foto-gunung-sari.jpg',
  'https://yourdomain.com/balai-desa.jpg',
];
